import { Alert, Box } from "@mui/material";

import errorCode, { ErrorCodeType } from "../../Config/errorCode";

export default function ApiErrorAlert({
  message,
  severity = "error",
}: {
  message?: ErrorCodeType;
  severity?: "info" | "error" | "warning" | "success";
}) {
  return (
    <Box sx={{ marginY: 2, textAlign: "left" }}>
      <Alert severity={severity}>
        {message
          ? errorCode[message]
          : "Internet is not reachable. In offline mode record the song and identify it later :)"}
      </Alert>
    </Box>
  );
}
