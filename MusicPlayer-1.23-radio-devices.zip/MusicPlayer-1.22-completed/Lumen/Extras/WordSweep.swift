import SwiftUI

/// Dane potrzebne do podświetlania słów w aktywnej linijce.
struct WordSweepInfo {
    let clock: PlaybackClock
    let lyrics: LyricsController
    let start: Double      // czas linijki w tekście
    let end: Double        // czas następnej linijki
    var words: [LyricRun] = []   // czasy słów/sylab ze źródła (puste = czas rozłożony proporcjonalnie)
}

/// Aktywna linijka karaoke. Podświetlenie jest liczone dla słów/sylab, a nie dla każdej litery;
/// to wygląda czyściej i ogranicza pracę SwiftUI podczas odtwarzania.
struct SweepText: View {
    @Environment(\.lyricsInk) private var ink
    @ObservedObject var clock: PlaybackClock
    let lyrics: LyricsController
    let text: String
    let start: Double
    let end: Double
    let fontSize: Double
    var words: [LyricRun] = []

    var body: some View {
        let t = lyrics.lyricTime(forPlayer: clock.time)
        let span = max(0.6, (end - start) * 0.92)
        let p = min(max((t - start) / span, 0), 1)
        let content: AttributedString = words.isEmpty ? attributed(progress: p) : attributed(runs: words, at: t)
        return Text(content)
            .font(.system(size: fontSize, weight: .bold))
            .multilineTextAlignment(.leading)
            .frame(maxWidth: .infinity, alignment: .leading)
            .transaction { $0.animation = nil }
            .accessibilityLabel(text)
    }

    /// Prawdziwe czasy słów/sylab: każdy kawałek płynnie rozjaśnia się w swoim przedziale czasu.
    private func attributed(runs: [LyricRun], at t: Double) -> AttributedString {
        var result = AttributedString()
        for run in runs {
            let progress = min(max((t - run.start) / max(run.end - run.start, 0.12), 0), 1)
            guard !run.text.isEmpty else { continue }
            var piece = AttributedString(run.text)
            piece.foregroundColor = ink.opacity(0.34 + 0.66 * progress)
            result.append(piece)
        }
        return result
    }

    private func attributed(progress p: Double) -> AttributedString {
        let words = text.split(separator: " ", omittingEmptySubsequences: true).map(String.init)
        guard !words.isEmpty else { return AttributedString(text) }
        let weights = words.map { Double($0.count + 1) }
        let total = weights.reduce(0, +)
        var result = AttributedString()
        var acc = 0.0
        for (i, w) in words.enumerated() {
            let a = acc / total
            acc += weights[i]
            let b = acc / total
            let wp = min(max((p - a) / max(b - a, 0.0001), 0), 1)
            var piece = AttributedString(i < words.count - 1 ? w + " " : w)
            piece.foregroundColor = ink.opacity(0.38 + 0.62 * wp)
            result.append(piece)
        }
        return result
    }
}

/// Bardzo powolne unoszenie się okładki (animacja idzie do systemu raz, bez pracy na klatkę).
struct FloatMotion: ViewModifier {
    var enabled: Bool
    @State private var phase = false

    func body(content: Content) -> some View {
        content
            .offset(y: enabled ? (phase ? -7 : 7) : 0)
            .rotation3DEffect(.degrees(enabled ? (phase ? 3 : -3) : 0), axis: (x: 0.2, y: 1, z: 0))
            .onAppear { restart() }
            .onChange(of: enabled) { _, _ in restart() }
    }

    private func restart() {
        phase = false
        guard enabled else { return }
        withAnimation(.easeInOut(duration: 5).repeatForever(autoreverses: true)) { phase = true }
    }
}
