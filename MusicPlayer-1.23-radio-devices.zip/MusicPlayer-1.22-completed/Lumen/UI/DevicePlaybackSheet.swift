import SwiftUI

/// Prosty ekran „graj gdzie indziej”. Natywny AVRoutePicker otwiera selektor iOS dla AirPlay,
/// Bluetooth i zgodnych odbiorników; stan wyjścia odświeża się automatycznie po każdej zmianie trasy.
struct DevicePlaybackSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.ink) private var ink
    @Environment(\.accentInk) private var accentInk
    @EnvironmentObject private var engine: PlayerEngine
    @EnvironmentObject private var volume: VolumeController
    @StateObject private var discovery = DeviceDiscovery.shared

    private var title: String {
        if engine.isRadio { return engine.radioSong?.title ?? engine.currentStation?.name ?? "Radio" }
        return engine.currentTrack?.title ?? "Nic nie gra"
    }

    private var subtitle: String {
        if engine.isRadio { return engine.radioSong?.artist ?? "Transmisja na żywo" }
        return engine.currentTrack?.artist ?? ""
    }

    private var lyrics: String {
        if engine.isRadio {
            return engine.radioLyrics?.split(whereSeparator: \.isNewline).prefix(2).joined(separator: "\n") ?? ""
        }
        return engine.lyrics.playbackPreview
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    routeCard
                    discoveryCard
                    nowPlayingCard
                    if !lyrics.isEmpty { lyricsCard }
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Głośność").font(.headline)
                        VolumeRow()
                    }
                    .padding(16)
                    .glassCard(radius: 20)
                    Text("Internet nie wymaga osobnego pozwolenia w iOS. Bluetooth i sieć lokalna poproszą o dostęp po rozpoczęciu wyszukiwania. Wykrywanie nie paruje samodzielnie słuchawek ani nie gwarantuje przesyłania tekstów na każdy telewizor.")
                        .font(.footnote)
                        .foregroundStyle(ink.opacity(0.65))
                }
                .padding(20)
            }
            .navigationTitle("Odtwarzaj na urządzeniu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Gotowe") { discovery.stopDiscovery(); dismiss() } } }
            .onDisappear { discovery.stopDiscovery() }
        }
    }

    private var discoveryCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Wykrywanie urządzeń", systemImage: "dot.radiowaves.left.and.right")
                .font(.headline).foregroundStyle(ink)
            Text(discovery.bluetoothState).font(.subheadline).foregroundStyle(ink.opacity(0.72))
            if !discovery.bluetoothDevices.isEmpty {
                ForEach(discovery.bluetoothDevices.prefix(5), id: \.self) { name in
                    Label(name, systemImage: "wave.3.right").font(.subheadline).foregroundStyle(ink)
                }
            }
            Divider().overlay(ink.opacity(0.15))
            Text(discovery.localNetworkState).font(.subheadline).foregroundStyle(ink.opacity(0.72))
            if !discovery.localDevices.isEmpty {
                ForEach(discovery.localDevices.prefix(8), id: \.self) { name in
                    Label(name, systemImage: "tv").font(.subheadline).foregroundStyle(ink)
                }
            }
            Button { discovery.startDiscovery() } label: {
                Label("Szukaj urządzeń", systemImage: "magnifyingglass")
                    .frame(maxWidth: .infinity).padding(.vertical, 5)
            }
            .buttonStyle(.borderedProminent)
            Text("Lista wykrywania obejmuje urządzenia BLE i usługi sieciowe. Dźwięk kieruj przez przycisk wyboru wyjścia iOS powyżej.")
                .font(.caption).foregroundStyle(ink.opacity(0.58))
        }
        .padding(16)
        .glassCard(radius: 20)
    }

    private var routeCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("AKTUALNE WYJŚCIE")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(ink.opacity(0.58))
            HStack(spacing: 12) {
                Image(systemName: engine.outputRoute.systemImage)
                    .font(.system(size: 25, weight: .semibold))
                    .foregroundStyle(accentInk)
                    .frame(width: 42, height: 42)
                    .background(accentInk.opacity(0.14), in: Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(engine.outputRoute.name).font(.system(size: 18, weight: .semibold)).foregroundStyle(ink)
                    Text(engine.outputRoute.detail).font(.subheadline).foregroundStyle(ink.opacity(0.65))
                }
                Spacer(minLength: 0)
                if engine.outputRoute.isExternal {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green).font(.title3)
                }
            }
            Divider().overlay(ink.opacity(0.15))
            HStack(spacing: 10) {
                AirPlayButton(color: accentInk).frame(width: 44, height: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Wybierz inne urządzenie").font(.subheadline.weight(.semibold)).foregroundStyle(ink)
                    Text("AirPlay, Apple TV, głośnik lub zgodne wyjście audio").font(.caption).foregroundStyle(ink.opacity(0.62))
                }
            }
        }
        .padding(16)
        .glassCard(radius: 20)
    }

    private var nowPlayingCard: some View {
        HStack(spacing: 12) {
            Group {
                if engine.isRadio {
                    RadioIcon(url: engine.currentStation?.icon, name: engine.currentStation?.name ?? "Radio", size: 54, radius: 12, active: engine.isPlaying)
                } else {
                    ArtworkView(size: 54, radius: 12)
                }
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 17, weight: .bold)).foregroundStyle(ink).lineLimit(2)
                if !subtitle.isEmpty { Text(subtitle).font(.subheadline).foregroundStyle(ink.opacity(0.68)).lineLimit(1) }
            }
            Spacer(minLength: 0)
        }
        .padding(16)
        .glassCard(radius: 20)
    }

    private var lyricsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Tekst teraz", systemImage: "text.quote")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(ink.opacity(0.72))
            Text(lyrics)
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(ink)
                .lineLimit(3)
        }
        .padding(16)
        .glassCard(radius: 20)
    }
}
