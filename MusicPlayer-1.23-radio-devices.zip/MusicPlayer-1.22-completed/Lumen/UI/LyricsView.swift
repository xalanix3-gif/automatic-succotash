import SwiftUI

/// Apple Music style synced lyrics: big bold lines, active line sharp, others dimmed and blurred.
struct LyricsView: View {
    @Environment(\.lyricsInk) private var lyricsInk
    @ObservedObject var lyrics: LyricsController
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var engine: PlayerEngine

    private let anchor = UnitPoint(x: 0, y: 0.22)
    @State private var translations: [String] = []

    private var translationKey: String {
        "\(engine.currentTrack?.id ?? "")|\(lyrics.lines.count)|\(settings.data.translateLyrics)|\(settings.data.translateTarget)"
    }

    private func loadTranslations() async {
        guard settings.data.translateLyrics, !lyrics.lines.isEmpty, let id = engine.currentTrack?.id else {
            translations = []
            return
        }
        let out = await LyricsTranslator.shared.translate(lyrics.lines.map { $0.text }, to: settings.data.translateTarget, key: id)
        if Task.isCancelled { return }
        translations = out ?? []
    }

    var body: some View {
        switch lyrics.phase {
        case .synced:
            // Bez animacji wejścia całego ekranu: animuje się wyłącznie właściwe podświetlenie karaoke.
            synced.id(engine.currentTrack?.id ?? "none")
        case .plain:
            PlainLyricsText(text: settings.data.censorProfanity ? Profanity.censor(lyrics.plainText) : lyrics.plainText)
                .id(engine.currentTrack?.id ?? "plain-lyrics")
        case .idle, .loading:
            VStack { Spacer(); ProgressView().tint(lyricsInk); Spacer() }
                .frame(maxWidth: .infinity)
        case .instrumental:
            message("Utwór instrumentalny", "music.note")
        case .notFound:
            message("Nie znaleziono tekstu", "text.quote")
        case .offline:
            message("Brak internetu. Tekst pojawi się sam, gdy połączenie wróci", "wifi.slash")
        }
    }

    private func message(_ text: String, _ icon: String) -> some View {
        VStack(spacing: 10) {
            Spacer()
            Image(systemName: icon).font(.system(size: 34, weight: .semibold))
            Text(text).font(.system(size: 22, weight: .bold))
            Spacer()
        }
        .foregroundStyle(lyricsInk.opacity(0.7))
        .frame(maxWidth: .infinity)
    }

    /// Cenzura liczona na całej linijce (wulgaryzm może być rozbity na sylaby), potem z powrotem pocięta na kawałki.
    private func censoredWords(_ words: [LyricRun]) -> [LyricRun] {
        guard settings.data.censorProfanity, !words.isEmpty else { return words }
        let joined = words.map { $0.text }.joined()
        let censored = Array(Profanity.censor(joined))
        guard censored.count == joined.count else { return words }
        var out = words
        var pos = 0
        for k in out.indices {
            let n = words[k].text.count
            out[k].text = String(censored[pos..<(pos + n)])
            pos += n
        }
        return out
    }

    private var synced: some View {
        ScrollViewReader { proxy in
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 26) {
                    Spacer().frame(height: 30)
                    ForEach(lyrics.lines) { line in
                        LyricLineView(text: settings.data.censorProfanity ? Profanity.censor(line.text) : line.text,
                                      words: censoredWords(line.words),
                                      distance: abs(line.id - lyrics.activeIndex),
                                      isActive: line.id == lyrics.activeIndex,
                                      fontSize: settings.data.lyricsFontSize,
                                      blurOn: true,
                                      sweep: WordSweepInfo(
                                        clock: engine.clock, lyrics: lyrics, start: line.time,
                                        end: line.id + 1 < lyrics.lines.count ? lyrics.lines[line.id + 1].time : line.time + 4),
                                      translation: translations.indices.contains(line.id)
                                        ? (settings.data.censorProfanity ? Profanity.censor(translations[line.id]) : translations[line.id]) : nil) {
                            engine.seek(to: max(0, lyrics.playerTime(forLyric: line.time)))
                        }
                        .id(line.id)
                    }
                    Spacer().frame(height: 280)
                }
            }
            .mask(
                LinearGradient(stops: [
                    .init(color: .clear, location: 0),
                    .init(color: .black, location: 0.10),
                    .init(color: .black, location: 0.86),
                    .init(color: .clear, location: 1)
                ], startPoint: .top, endPoint: .bottom)
            )
            .onChange(of: lyrics.activeIndex) { _, newIndex in
                guard newIndex >= 0 else { return }
                // Jak w Spotify: jeden, spokojny ruch w górę (bez sprężynowania), a linie tylko zmieniają jasność.
                withAnimation(.easeOut(duration: 0.24)) {
                    proxy.scrollTo(newIndex, anchor: anchor)
                }
            }
            .task(id: translationKey) { await loadTranslations() }
            .onAppear {
                if lyrics.activeIndex >= 0 { proxy.scrollTo(lyrics.activeIndex, anchor: anchor) }
            }
        }
    }
}

struct LyricLineView: View {
    @Environment(\.lyricsInk) private var lyricsInk
    let text: String
    var words: [LyricRun] = []
    let distance: Int
    let isActive: Bool
    let fontSize: Double
    let blurOn: Bool
    var sweep: WordSweepInfo? = nil
    var translation: String? = nil
    let onTap: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if isActive, let s = sweep, !text.isEmpty {
                SweepText(clock: s.clock, lyrics: s.lyrics, text: text, start: s.start, end: s.end, fontSize: fontSize, words: words)
            } else {
                Text(text.isEmpty ? "• • •" : text)
                    .font(.system(size: fontSize, weight: .bold))
                    .foregroundStyle(lyricsInk)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            if let tr = translation, !tr.isEmpty, !text.isEmpty, tr.lowercased() != text.lowercased() {
                Text(tr)
                    .font(.system(size: max(15, fontSize * 0.5), weight: .semibold))
                    .foregroundStyle(lyricsInk.opacity(0.75))
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        // Bez rozmycia i skali (to powodowało "szarpanie"): sama płynna zmiana jasności aktywnej linii.
        .opacity(isActive ? 1 : (distance == 1 ? 0.5 : 0.36))
        .animation(.easeInOut(duration: 0.35), value: isActive)
        .contentShape(Rectangle())
        .onTapGesture(perform: onTap)
    }
}

// MARK: - Picker of another lyrics version

struct LyricsPickerSheet: View {
    @EnvironmentObject var engine: PlayerEngine
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var results: [LyricsCandidate] = []
    @State private var sourceResults: [LyricsCandidate] = []
    @State private var loadingSources = false
    @State private var loading = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("Wykonawca i tytuł", text: $query)
                        .submitLabel(.search)
                        .onSubmit { Task { await run() } }
                } footer: {
                    Text("Wybierz wersję o takim samym czasie trwania jak piosenka (zielony czas). Inna wersja = inny rytm tekstu.")
                }
                if loadingSources || !sourceResults.isEmpty {
                    Section("Wersje ze wszystkich źródeł") {
                        if loadingSources && sourceResults.isEmpty {
                            HStack { Spacer(); ProgressView(); Spacer() }
                        }
                        ForEach(sourceResults, id: \.uid) { c in
                            Button {
                                engine.chooseLyrics(c)
                                dismiss()
                            } label: { row(c) }
                        }
                    }
                }
                if loading {
                    HStack { Spacer(); ProgressView(); Spacer() }
                }
                ForEach(results, id: \.uid) { c in
                    Button {
                        engine.chooseLyrics(c)
                        dismiss()
                    } label: { row(c) }
                }
            }
            .navigationTitle("Wersja tekstu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Gotowe") { dismiss() } } }
            .task {
                if let t = engine.currentTrack, let g = TitleCleaner.guesses(title: t.title, channel: t.artist).first {
                    query = "\(g.artist) \(g.title)"
                }
                Task { await loadSources() }
                await run()
            }
        }
        .presentationDetents([.large])
    }

    private func row(_ c: LyricsCandidate) -> some View {
        let video = engine.currentTrack?.duration ?? 0
        let isCurrent = engine.lyrics.current?.uid == c.uid
        return HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(c.title.isEmpty ? "—" : c.title).font(.system(size: 16, weight: .semibold)).lineLimit(2)
                Text(c.artist).font(.system(size: 14)).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 6) {
                    Text(c.source ?? "")
                    if let d = c.duration, d > 0 {
                        Text("· \(Fmt.time(d))" + (video > 0 ? " (film \(Fmt.time(video)))" : ""))
                            .foregroundStyle(video > 0 && abs(d - video) <= 2 ? Color.green : Color.orange)
                    }
                    Text(c.hasWords ? "· słowo po słowie" : (c.hasSynced ? "· z synchronizacją" : "· zwykły tekst"))
                }
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            if isCurrent { Image(systemName: "checkmark.circle.fill") }
        }
        .contentShape(Rectangle())
    }

    private func loadSources() async {
        guard let track = engine.currentTrack else { return }
        loadingSources = true
        let list = await LyricsService.shared.providerCandidates(for: track)
        sourceResults = list.sorted { ($0.hasWords ? 0 : 1) < ($1.hasWords ? 0 : 1) }
        loadingSources = false
    }

    private func run() async {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        loading = true
        let list = await LyricsService.shared.search(query: q)
        let video = engine.currentTrack?.duration ?? 0
        // Z synchronizacją i najbliższym czasem trwania na górze.
        results = list.sorted {
            if $0.hasSynced != $1.hasSynced { return $0.hasSynced }
            guard video > 0 else { return false }
            return abs(($0.duration ?? 9999) - video) < abs(($1.duration ?? 9999) - video)
        }
        loading = false
    }
}


/// Teksty bez znaczników czasu nie udają karaoke. Pojawiają się jedynie krótkim fade-in bez ruchu i skalowania.
private struct PlainLyricsText: View {
    @Environment(\.lyricsInk) private var lyricsInk
    let text: String
    @State private var isVisible = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            Text(text)
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(lyricsInk.opacity(0.92))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 16)
            Spacer().frame(height: 30)
        }
        .opacity(isVisible ? 1 : 0)
        .onAppear {
            withAnimation(.easeOut(duration: 0.18)) { isVisible = true }
        }
    }
}
