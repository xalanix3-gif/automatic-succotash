import SwiftUI
import PhotosUI
import UIKit

struct RadioView: View {
    @Environment(\.ink) private var ink
    @Environment(\.accentInk) private var accentInk
    @ObservedObject var store: RadioStore
    var isVisible: Bool
    var openPlayer: () -> Void = {}
    @EnvironmentObject var engine: PlayerEngine
    @EnvironmentObject var toast: ToastCenter

    @State private var section = 0          // 0 = stacje, 1 = ulubione
    @State private var query = ""
    @State private var showStationEditor = false
    @State private var stationBeingEdited: RadioStation? = nil
    @FocusState private var focused: Bool

    private var list: [RadioStation] { section == 0 ? store.stations : store.favorites }

    var body: some View {
        VStack(spacing: 0) {
            ScreenHeader("Radio") {
                GlassIconButton(systemName: "plus", size: 40) {
                    stationBeingEdited = nil
                    showStationEditor = true
                }
            }

            if engine.isRadio, engine.currentTrack != nil { nowPlayingCard }

            Picker("", selection: $section) {
                Text("Stacje").tag(0)
                Text("Ulubione").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 20)
            .padding(.bottom, 10)

            if section == 0 { searchField.padding(.horizontal, 20).padding(.bottom, 8) }

            if section == 0 && store.loading {
                ProgressView().tint(accentInk).padding(.top, 40)
                Spacer()
            } else if list.isEmpty {
                ScrollView {
                    EmptyHint(icon: section == 0 ? "dot.radiowaves.left.and.right" : "star",
                              title: section == 0 ? (store.message ?? "Brak stacji") : "Brak ulubionych",
                              message: section == 0
                                ? "Pociągnij, żeby spróbować jeszcze raz."
                                : "Kliknij gwiazdkę przy stacji albo dodaj własną przyciskiem +.")
                        .padding(.top, 50)
                }
                .refreshable { if section == 0 { await store.search(query) } }
            } else {
                List {
                    ForEach(Array(list.enumerated()), id: \.element.id) { index, s in
                        row(s, index: index)
                            .listRowBackground(Color.clear)
                            .listRowSeparator(.hidden)
                            .swipeActions(edge: .trailing) {
                                if section == 1 {
                                    Button(role: .destructive) { store.toggleFavorite(s) } label: {
                                        Label("Usuń", systemImage: "trash")
                                    }
                                }
                            }
                            .swipeActions(edge: .leading, allowsFullSwipe: false) {
                                if s.id.hasPrefix("custom-") {
                                    Button {
                                        stationBeingEdited = s
                                        showStationEditor = true
                                    } label: {
                                        Label("Edytuj", systemImage: "pencil")
                                    }
                                    .tint(accentInk)
                                }
                            }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .refreshable { if section == 0 { await store.search(query) } }
            }
        }
        .task(id: isVisible) {
            if isVisible && store.stations.isEmpty && !store.loading {
                await store.loadPopular()
            }
        }
        .sheet(isPresented: $showStationEditor) {
            RadioStationEditor(station: stationBeingEdited) { id, name, url, imageData, clearIcon in
                if store.saveCustom(id: id, name: name, urlText: url,
                                    iconData: imageData, clearIcon: clearIcon) {
                    section = 1
                    toast.show(id == nil ? "Dodano stację" : "Zapisano stację")
                    showStationEditor = false
                } else {
                    toast.show("Wpisz prawidłowy adres strumienia HTTPS lub HTTP")
                }
            }
        }
    }

    /// Karta na górze: ikona stacji, obok grający utwór. Dotknięcie otwiera ekran radia (z tekstem piosenki).
    private var nowPlayingCard: some View {
        Button(action: openPlayer) {
            HStack(spacing: 12) {
                RadioIcon(url: engine.currentStation?.icon, name: engine.currentStation?.name ?? "Radio", size: 56, radius: 14, active: engine.isPlaying)
                VStack(alignment: .leading, spacing: 3) {
                    Text(engine.currentStation?.name ?? engine.currentTrack?.title ?? "Radio")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(ink.opacity(0.65))
                        .lineLimit(1)
                    Text(engine.isConnecting ? "Łączenie ze stacją…" : (engine.radioSong?.title ?? "Czekam na tytuł utworu"))
                        .font(.system(size: 17, weight: .bold))
                        .foregroundStyle(ink)
                        .lineLimit(1)
                    if let artist = engine.radioSong?.artist, !artist.isEmpty {
                        Text(artist)
                            .font(.system(size: 13))
                            .foregroundStyle(ink.opacity(0.7))
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.up")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(ink.opacity(0.6))
            }
            .padding(12)
            .contentShape(Rectangle())
            .glass(RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 20)
        .padding(.bottom, 10)
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(ink.opacity(0.7))
            TextField("Szukaj stacji", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .submitLabel(.search)
                .focused($focused)
                .foregroundStyle(ink)
                .onSubmit { Task { await store.search(query) } }
            if !query.isEmpty {
                Button {
                    query = ""
                    Task { await store.loadPopular() }
                } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(ink.opacity(0.6))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 46)
        .glass(Capsule())
    }

    private func row(_ s: RadioStation, index: Int) -> some View {
        let isCurrent = engine.currentTrack?.id == s.track.id
        return HStack(spacing: 8) {
            Button {
                focused = false
                engine.playRadio(list, startAt: index)
            } label: {
                HStack(spacing: 12) {
                    RadioIcon(url: s.icon, name: s.name, size: 52, radius: 12, active: isCurrent && engine.isPlaying)

                    VStack(alignment: .leading, spacing: 3) {
                        Text(s.name)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(ink)
                            .lineLimit(1)
                        // Przy grającej stacji zamiast opisu widać aktualny utwór.
                        Text(isCurrent && engine.radioSong != nil
                             ? "♪ \(engine.radioSong!.display)"
                             : (s.detail.isEmpty ? "Na żywo" : s.detail))
                            .font(.system(size: 13))
                            .foregroundStyle(ink.opacity(isCurrent && engine.radioSong != nil ? 0.9 : 0.65))
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button { store.toggleFavorite(s) } label: {
                Image(systemName: store.isFavorite(s) ? "star.fill" : "star")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(store.isFavorite(s) ? accentInk : ink.opacity(0.7))
                    .frame(width: 48, height: 56)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }
}

/// Formularz własnej stacji z trwałą ikoną z galerii oraz automatyczną ikoną, gdy zdjęcie nie zostało wybrane.
private struct RadioStationEditor: View {
    @Environment(\.dismiss) private var dismiss
    let station: RadioStation?
    let onSave: (String?, String, String, Data?, Bool) -> Void

    @State private var name: String
    @State private var streamURL: String
    @State private var pickerItem: PhotosPickerItem?
    @State private var imageData: Data?
    @State private var image: UIImage?
    @State private var clearIcon = false

    init(station: RadioStation?, onSave: @escaping (String?, String, String, Data?, Bool) -> Void) {
        self.station = station
        self.onSave = onSave
        _name = State(initialValue: station?.name ?? "")
        _streamURL = State(initialValue: station?.url ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section(
                    content: {
                        TextField("Nazwa", text: $name)
                        TextField("Adres strumienia (https://…)", text: $streamURL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                    },
                    header: { Text("Stacja") },
                    footer: {
                        Text("Wklej bezpośredni link do MP3, AAC albo HLS (m3u8). Gdy logo nie jest wybrane, aplikacja spróbuje wykryć je automatycznie.")
                    }
                )

                Section("Ikona stacji") {
                    HStack(spacing: 14) {
                        if let image {
                            Image(uiImage: image).resizable().scaledToFill()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        } else {
                            RadioIcon(url: clearIcon ? nil : station?.icon,
                                      name: name.isEmpty ? "Radio" : name, size: 56, radius: 12)
                        }
                        PhotosPicker(selection: $pickerItem, matching: .images) {
                            Label(imageData == nil ? "Wybierz własną ikonę" : "Zmień ikonę", systemImage: "photo")
                        }
                    }
                    if imageData != nil || station?.icon?.hasPrefix("local:") == true {
                        Button("Przywróć automatyczną ikonę", role: .destructive) {
                            image = nil
                            imageData = nil
                            pickerItem = nil
                            clearIcon = true
                        }
                    }
                }
            }
            .navigationTitle(station == nil ? "Dodaj stację" : "Edytuj stację")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Anuluj") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Zapisz") { onSave(station?.id, name, streamURL, imageData, clearIcon) }
                        .fontWeight(.semibold)
                }
            }
        }
        .task(id: station?.icon) {
            guard let key = station?.icon, key.hasPrefix("local:") else { return }
            image = await RadioIconCache.shared.load(key)
        }
        .onChange(of: pickerItem) { _, item in
            guard let item else { return }
            Task {
                guard let data = try? await item.loadTransferable(type: Data.self), let picked = UIImage(data: data) else { return }
                imageData = data
                image = picked
                clearIcon = false
            }
        }
    }
}
