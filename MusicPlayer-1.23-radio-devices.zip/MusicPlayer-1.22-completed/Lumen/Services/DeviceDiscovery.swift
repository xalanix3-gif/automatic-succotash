import Foundation
import CoreBluetooth
import Network

/// Prosi o dostęp do Bluetooth dopiero po świadomym wejściu w wyszukiwanie urządzeń.
/// iOS nie pozwala aplikacjom na automatyczne parowanie z głośnikami/samochodami audio;
/// dla wyjścia audio nadal używamy systemowego selektora AirPlay/Bluetooth.
@MainActor
final class DeviceDiscovery: NSObject, ObservableObject {
    static let shared = DeviceDiscovery()

    @Published private(set) var bluetoothState = "Bluetooth nieuruchomiony"
    @Published private(set) var bluetoothDevices: [String] = []
    @Published private(set) var localDevices: [String] = []
    @Published private(set) var localNetworkState = "Wyszukiwanie sieci lokalnej nieuruchomione"

    private var central: CBCentralManager?
    private var browsers: [NWBrowser] = []
    private var localNames = Set<String>()

    func startDiscovery() {
        if central == nil {
            central = CBCentralManager(delegate: self, queue: .main)
        } else if central?.state == .poweredOn {
            central?.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        }
        startLocalNetworkDiscovery()
    }

    func stopDiscovery() {
        central?.stopScan()
        browsers.forEach { $0.cancel() }
        browsers.removeAll()
    }

    private func startLocalNetworkDiscovery() {
        guard browsers.isEmpty else { return }
        localNetworkState = "Szukam zgodnych odbiorników w sieci lokalnej…"
        for service in ["_airplay._tcp", "_raop._tcp", "_googlecast._tcp"] {
            let browser = NWBrowser(for: .bonjour(type: service, domain: nil), using: .tcp)
            browser.stateUpdateHandler = { [weak self] state in
                Task { @MainActor in
                    if case .failed(let error) = state {
                        self?.localNetworkState = "Nie udało się przeszukać sieci: \(error.localizedDescription)"
                    }
                }
            }
            browser.browseResultsChangedHandler = { [weak self] results, _ in
                let names = results.compactMap { result -> String? in
                    guard case .service(let name, _, _, _) = result.endpoint else { return nil }
                    return name
                }
                Task { @MainActor in
                    self?.localNames.formUnion(names)
                    self?.localDevices = Array(self?.localNames ?? []).sorted()
                    self?.localNetworkState = self?.localDevices.isEmpty == false
                        ? "Znaleziono zgodne usługi w sieci lokalnej"
                        : "Nie znaleziono zgodnych odbiorników (to nie wyklucza AirPlay)"
                }
            }
            browser.start(queue: .main)
            browsers.append(browser)
        }
    }
}

extension DeviceDiscovery: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            bluetoothState = "Bluetooth włączony — wyszukuję urządzenia BLE"
            central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        case .poweredOff: bluetoothState = "Włącz Bluetooth w Ustawieniach"
        case .unauthorized: bluetoothState = "Brak zgody na Bluetooth. Zmień ją w Ustawieniach iOS."
        case .unsupported: bluetoothState = "To urządzenie nie obsługuje Bluetooth LE"
        case .resetting: bluetoothState = "Ponowne uruchamianie Bluetooth…"
        case .unknown: bluetoothState = "Sprawdzanie stanu Bluetooth…"
        @unknown default: bluetoothState = "Nieznany stan Bluetooth"
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let name = peripheral.name
            ?? advertisementData[CBAdvertisementDataLocalNameKey] as? String
            ?? "Urządzenie BLE \(peripheral.identifier.uuidString.prefix(6))"
        if !bluetoothDevices.contains(name) { bluetoothDevices.append(name); bluetoothDevices.sort() }
    }
}
