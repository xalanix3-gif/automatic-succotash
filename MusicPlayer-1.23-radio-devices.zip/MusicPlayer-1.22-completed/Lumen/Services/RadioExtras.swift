import SwiftUI
import AVFoundation
import UIKit

// MARK: - Aktualnie grany utwór w radiu

struct RadioSong: Equatable {
    var artist: String
    var title: String

    var display: String { artist.isEmpty ? title : "\(artist) – \(title)" }

    /// Stabilny identyfikator do zapisu tekstu na dysku (bez znaków specjalnych).
    var cacheID: String {
        var h: UInt64 = 14695981039346656037          // FNV-1a
        for b in "\(artist.lowercased())|\(title.lowercased())".utf8 { h = (h ^ UInt64(b)) &* 1099511628211 }
        return "radiosong-" + String(h, radix: 16)
    }

    /// "Wykonawca - Tytuł" z metadanych strumienia (ICY StreamTitle). Zwraca nil, gdy to nie wygląda na utwór.
    static func parse(_ raw: String, station: String) -> RadioSong? {
        var s = HTMLEntities.decode(raw)
            .replacingOccurrences(of: "\0", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if s.lowercased().hasPrefix("streamtitle=") {
            s = String(s.dropFirst("streamtitle=".count))
        }
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
        let lower = s.lowercased()
        let noise = ["advertisement", "ad break", "commercial break", "reklama", "wiadomości", "news bulletin"]
        guard s.count >= 3, s != "-", lower != station.lowercased(), !noise.contains(where: lower.contains) else { return nil }
        for separator in [" - ", " – ", " — ", " | "] {
            if let r = s.range(of: separator) {
                let artist = String(s[..<r.lowerBound]).trimmingCharacters(in: .whitespaces)
                let title = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                if title.count >= 2 { return RadioSong(artist: artist, title: title) }
            }
        }
        return RadioSong(artist: "", title: s)
    }
}

/// Odbiera metadane strumienia: ICY (mp3/aac) i ID3 (HLS). Wywołuje `onUpdate` na głównym wątku.
final class RadioMetaReader: NSObject, AVPlayerItemMetadataOutputPushDelegate {
    var onUpdate: ((_ streamTitle: String?, _ artist: String?, _ title: String?) -> Void)?

    func attach(to item: AVPlayerItem) {
        let output = AVPlayerItemMetadataOutput(identifiers: nil)
        output.setDelegate(self, queue: .main)
        item.add(output)
    }

    func metadataOutput(_ output: AVPlayerItemMetadataOutput,
                        didOutputTimedMetadataGroups groups: [AVTimedMetadataGroup],
                        from track: AVPlayerItemTrack?) {
        var stream: String? = nil, artist: String? = nil, title: String? = nil
        for group in groups {
            for item in group.items {
                guard let text = item.stringValue, !text.isEmpty else { continue }
                switch item.identifier {
                case .icyMetadataStreamTitle?: stream = text
                case .id3MetadataLeadPerformer?, .commonIdentifierArtist?: artist = text
                case .id3MetadataTitleDescription?, .commonIdentifierTitle?: title = text
                default: break
                }
            }
        }
        if stream != nil || artist != nil || title != nil { onUpdate?(stream, artist, title) }
    }
}

// MARK: - Logo stacji

/// Logo stacji z pamięcią i dyskiem (PNG, więc przezroczystość zostaje), żeby listy nie lagowały.
final class RadioIconCache: @unchecked Sendable {
    static let shared = RadioIconCache()
    private let cache = NSCache<NSString, UIImage>()
    private let dir: URL
    private let customDir: URL
    private let lock = NSLock()
    private var failed = Set<String>()

    init() {
        cache.countLimit = 300
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        var folder = base.appendingPathComponent("Lumen/RadioIcons", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? folder.setResourceValues(values)
        dir = folder
        let localFolder = base.appendingPathComponent("Lumen/CustomRadioIcons", isDirectory: true)
        try? FileManager.default.createDirectory(at: localFolder, withIntermediateDirectories: true)
        customDir = localFolder
    }

    private func file(for url: String) -> URL {
        var h: UInt64 = 14695981039346656037          // FNV-1a
        for b in url.utf8 { h = (h ^ UInt64(b)) &* 1099511628211 }
        return dir.appendingPathComponent(String(h, radix: 16) + ".png")
    }

    func cached(_ url: String) -> UIImage? { cache.object(forKey: url as NSString) }

    /// Zapisuje przeskalowaną własną ikonę w danych aplikacji. Do modelu trafia jedynie stabilna nazwa pliku,
    /// nigdy ścieżka z galerii użytkownika.
    func storeCustom(_ data: Data) -> String? {
        guard let image = UIImage(data: data),
              let png = ArtworkLoader.downscale(image, maxSide: 512).pngData() else { return nil }
        let key = "local:" + UUID().uuidString + ".png"
        let name = String(key.dropFirst("local:".count))
        let url = customDir.appendingPathComponent(name)
        guard (try? png.write(to: url, options: .atomic)) != nil else { return nil }
        cache.setObject(UIImage(data: png) ?? image, forKey: key as NSString)
        return key
    }

    func load(_ urlString: String) async -> UIImage? {
        if let hit = cached(urlString) { return hit }
        if urlString.hasPrefix("local:") {
            let name = String(urlString.dropFirst("local:".count))
            let url = customDir.appendingPathComponent(name)
            guard let data = try? Data(contentsOf: url), let image = UIImage(data: data) else { return nil }
            cache.setObject(image, forKey: urlString as NSString)
            return image
        }
        let path = file(for: urlString)
        if let data = try? Data(contentsOf: path), let img = UIImage(data: data) {
            cache.setObject(img, forKey: urlString as NSString)
            return img
        }
        lock.lock(); let skip = failed.contains(urlString); lock.unlock()
        guard !skip, let url = URL(string: urlString), url.scheme?.hasPrefix("http") == true else { return nil }
        // Nie polegaj na jednym serwerze faviconów. Dla automatycznie wykrytych ikon próbujemy
        // kilku dostawców; dzięki temu awaria jednego endpointu nie kończy się od razu literą.
        var candidates = [url]
        if let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
           let domain = components.queryItems?.first(where: { $0.name == "domain" })?.value,
           !domain.isEmpty {
            let safeDomain = domain.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? domain
            for fallback in ["https://icon.horse/icon/\(safeDomain)",
                             "https://favicon.im/\(safeDomain)?size=128",
                             "https://www.google.com/s2/favicons?domain=\(safeDomain)&sz=128"] {
                if let candidate = URL(string: fallback), !candidates.contains(candidate) { candidates.append(candidate) }
            }
        }
        var loaded: UIImage?
        for candidate in candidates {
            var request = URLRequest(url: candidate)
            request.timeoutInterval = 5
            guard let (data, resp) = try? await URLSession.shared.data(for: request),
                  (resp as? HTTPURLResponse)?.statusCode == 200,
                  let image = UIImage(data: data), image.size.width > 1, image.size.height > 1 else { continue }
            loaded = image
            break
        }
        guard let full = loaded else {
            lock.lock(); failed.insert(urlString); lock.unlock()
            return nil
        }
        let small = ArtworkLoader.downscale(full, maxSide: 256)
        cache.setObject(small, forKey: urlString as NSString)
        if let png = small.pngData() { try? png.write(to: path, options: .atomic) }
        return small
    }
}

struct RadioIcon: View {
    @Environment(\.ink) private var ink
    let url: String?
    var name: String = "Radio"
    var size: CGFloat = 52
    var radius: CGFloat? = nil
    var active: Bool = false
    @State private var image: UIImage?

    init(url: String?, name: String = "Radio", size: CGFloat = 52, radius: CGFloat? = nil, active: Bool = false) {
        self.url = url
        self.name = name
        self.size = size
        self.radius = radius
        self.active = active
        _image = State(initialValue: url.flatMap { RadioIconCache.shared.cached($0) })
    }

    var body: some View {
        let r = radius ?? size * 0.2
        ZStack {
            RoundedRectangle(cornerRadius: r, style: .continuous)
                .fill(image == nil ? ink.opacity(0.12) : Color.white.opacity(0.95))
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .padding(size * 0.1)
            } else {
                StationGlyph(name: name, active: active, size: size)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: r, style: .continuous))
        .task(id: url) {
            guard let u = url, !u.isEmpty else { image = nil; return }
            if let hit = RadioIconCache.shared.cached(u) { image = hit; return }
            image = nil
            image = await RadioIconCache.shared.load(u)
        }
    }
}

/// Niezależny od sieci, charakterystyczny znak dla każdej stacji bez prawdziwego logo.
/// Dzięki temu żadna pozycja na liście nie jest pustym, identycznym symbolem radia.
private struct StationGlyph: View {
    @Environment(\.ink) private var ink
    let name: String
    let active: Bool
    let size: CGFloat

    private var hue: Double {
        let value = name.unicodeScalars.reduce(UInt64(14695981039346656037)) { partial, scalar in
            (partial ^ UInt64(scalar.value)) &* 1099511628211
        }
        return Double(value % 360) / 360
    }

    private var initial: String {
        let compact = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return compact.first.map { String($0).uppercased() } ?? "R"
    }

    private var symbol: String {
        let symbols = ["antenna.radiowaves.left.and.right", "waveform", "music.note", "radio", "dot.radiowaves.left.and.right", "music.mic"]
        let hash = name.unicodeScalars.reduce(UInt64(14695981039346656037)) { ($0 ^ UInt64($1.value)) &* 1099511628211 }
        return symbols[Int(hash % UInt64(symbols.count))]
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            RoundedRectangle(cornerRadius: size * 0.2, style: .continuous)
                .fill(Color(hue: hue, saturation: 0.55, brightness: active ? 0.9 : 0.68))
            Image(systemName: symbol)
                .resizable().scaledToFit()
                .foregroundStyle(.white.opacity(0.95))
                .padding(size * 0.22)
            Text(initial)
                .font(.system(size: max(9, size * 0.17), weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
                .frame(width: size * 0.28, height: size * 0.28)
                .background(Color.black.opacity(0.34), in: Circle())
                .padding(size * 0.06)
        }
    }
}

// MARK: - Ekran odtwarzacza radia

struct RadioNowPlayingView: View {
    @Environment(\.ink) private var ink
    @Environment(\.accentInk) private var accentInk
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var engine: PlayerEngine
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var volume: VolumeController
    @State private var showDevicePicker = false

    private var station: RadioStation? { engine.currentStation }

    var body: some View {
        ZStack {
            AnimatedBackground(isActive: true)
            VStack(spacing: 18) {
                Capsule().fill(ink.opacity(0.3)).frame(width: 40, height: 5).padding(.top, 8)

                header
                songCard
                lyricsArea
                VolumeRow()
                controls
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 16)
        }
        .sheet(isPresented: $showDevicePicker) {
            DevicePlaybackSheet()
                .environmentObject(engine)
                .environmentObject(volume)
                .preferredColorScheme(settings.colorScheme)
                .tint(accentInk)
        }
    }

    private var header: some View {
        HStack(spacing: 14) {
            RadioIcon(url: station?.icon, name: station?.name ?? "Radio", size: 72, radius: 16, active: engine.isPlaying)
            VStack(alignment: .leading, spacing: 5) {
                Text(station?.name ?? engine.currentTrack?.title ?? "Radio")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(ink)
                    .lineLimit(2)
                HStack(spacing: 6) {
                    Circle().fill(Color.red).frame(width: 8, height: 8)
                    Text(engine.isConnecting ? "Łączenie…" : "NA ŻYWO")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(ink.opacity(0.75))
                    if let d = station?.detail, !d.isEmpty {
                        Text("· \(d)")
                            .font(.system(size: 12))
                            .foregroundStyle(ink.opacity(0.6))
                            .lineLimit(1)
                    }
                }
            }
            Spacer(minLength: 0)
            Button { showDevicePicker = true } label: {
                Image(systemName: "airplayaudio")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(ink)
                    .frame(width: 46, height: 46)
                    .glass(Circle(), interactive: true)
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var songCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("TERAZ GRA")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(ink.opacity(0.55))
            if engine.isConnecting {
                HStack(spacing: 10) {
                    ProgressView().tint(accentInk)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Łączę ze stacją…").font(.system(size: 18, weight: .semibold)).foregroundStyle(ink)
                        Text("Czekam na dźwięk i metadane utworu.").font(.system(size: 13)).foregroundStyle(ink.opacity(0.62))
                    }
                }
            } else if let s = engine.radioSong {
                Text(s.title)
                    .font(.system(size: 24, weight: .bold))
                    .foregroundStyle(ink)
                    .lineLimit(3)
                if !s.artist.isEmpty {
                    Text(s.artist)
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(ink.opacity(0.75))
                        .lineLimit(2)
                }
            } else {
                Text("Stacja nie przekazuje tytułu")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(ink.opacity(0.8))
                Text("Może lecieć reklama, wiadomości albo zapowiedź. Gdy stacja przekaże tytuł, tekst wyszuka się automatycznie.")
                    .font(.system(size: 13))
                    .foregroundStyle(ink.opacity(0.6))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .glass(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    @ViewBuilder private var lyricsArea: some View {
        Group {
            if engine.isConnecting {
                VStack(spacing: 8) {
                    ProgressView().tint(accentInk)
                    Text("Łączenie ze stacją…").font(.system(size: 14)).foregroundStyle(ink.opacity(0.65))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if engine.radioSong == nil {
                Spacer(minLength: 0)
            } else if engine.radioLyricsLoading {
                VStack { ProgressView().tint(accentInk); Text("Szukam tekstu…").font(.system(size: 13)).foregroundStyle(ink.opacity(0.6)) }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let text = engine.radioLyrics {
                RadioLyricsText(text: settings.data.censorProfanity ? Profanity.censor(text) : text)
                    .id(text)
            } else {
                VStack(spacing: 6) {
                    Image(systemName: "text.quote").font(.system(size: 26)).foregroundStyle(ink.opacity(0.4))
                    Text("Nie znaleziono tekstu tej piosenki")
                        .font(.system(size: 14))
                        .foregroundStyle(ink.opacity(0.6))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .frame(maxHeight: .infinity)
    }

    private var controls: some View {
        HStack(spacing: 36) {
            Button { engine.previous() } label: {
                Image(systemName: "backward.fill").font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(ink).frame(width: 64, height: 64).contentShape(Rectangle())
            }
            Button { engine.togglePlayPause() } label: {
                Image(systemName: engine.wantsPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 32, weight: .bold))
                    .foregroundStyle(ink)
                    .frame(width: 78, height: 78)
                    .glass(Circle(), interactive: true)
            }
            Button { engine.next() } label: {
                Image(systemName: "forward.fill").font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(ink).frame(width: 64, height: 64).contentShape(Rectangle())
            }
        }
        .buttonStyle(.plain)
    }
}

/// Pojedyncze, lekkie wejście tekstu dla radia. Nie ma skali ani efektu pudełka, więc nie obciąża listy.
private struct RadioLyricsText: View {
    @Environment(\.ink) private var ink
    let text: String
    @State private var shown = false

    var body: some View {
        ScrollView {
            Text(text)
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(ink.opacity(0.92))
                .lineSpacing(5)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 6)
                .opacity(shown ? 1 : 0)
        }
        .onAppear {
            // Tylko lekkie pojawienie się tekstu; bez przesuwania/skalowania karty radia.
            withAnimation(.easeOut(duration: 0.18)) { shown = true }
        }
    }
}
